package com.ritik.screeneditor

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var cmd: EditText
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("p", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 15f; setPadding(0, 24, 0, 6) }
        fun field(h: String) = EditText(this).also { it.hint = h }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        info = TextView(this)
        val key = field("Gemini API key").apply {
            setText(p.getString("key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val name = field("Assistant ka naam (optional, jaise Rohan)").apply { setText(p.getString("name", "")) }
        cmd = field("Command: CapCut kholo aur clip 10 second pe split karo")

        root.addView(TextView(this).apply { text = "Screen Editor Agent"; textSize = 24f })
        root.addView(info)
        root.addView(btn("1. Accessibility service chalu karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(label("2. Gemini key aur naam"))
        root.addView(key)
        root.addView(name)
        root.addView(label("3. Command"))
        root.addView(cmd)
        root.addView(btn("Mic se bolo") {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            try { startActivityForResult(i, 1) } catch (e: Exception) {
                Toast.makeText(this, "Is phone pe voice input nahi mila, likh ke do.", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(btn("Agent chalao") {
            val svc = AgentService.instance
            val k = key.text.toString().trim()
            var task = cmd.text.toString().trim()
            val n = name.text.toString().trim()
            if (n.isNotEmpty() && task.startsWith(n, ignoreCase = true)) task = task.substring(n.length).trimStart(' ', ',')
            when {
                svc == null -> toast("Pehle accessibility service chalu karo.")
                k.isEmpty() -> toast("Gemini API key daalo.")
                task.isEmpty() -> toast("Command likho ya bolo.")
                Agent.running -> toast("Agent pehle se chal raha hai.")
                else -> {
                    p.edit().putString("key", k).putString("name", n).apply()
                    Agent.start(svc, task, k)
                    moveTaskToBack(true)
                }
            }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        info.text = if (AgentService.instance != null) "Service: chalu hai" else "Service: band hai (neeche button se chalu karo)"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { cmd.setText(it) }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
