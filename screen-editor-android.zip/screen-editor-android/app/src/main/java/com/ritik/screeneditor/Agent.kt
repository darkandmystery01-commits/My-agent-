package com.ritik.screeneditor

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Loop: screenshot -> Gemini picks ONE action -> execute -> repeat. Floating panel has Roko / Haan / Nahi. */
object Agent {
    private const val MODEL = "gemini-2.5-flash"
    private const val MAX_STEPS = 40

    private const val SYSTEM = """You operate an Android phone to help the user edit videos in apps like CapCut or InShot.
Each turn you get a screenshot and the task. Reply with ONE next action as JSON only.
Coordinates are normalized 0-1000 (x: left to right, y: top to bottom) of the screenshot.
JSON keys: thought (short), action, x, y, x2, y2, text, seconds, ms, needs_confirm (bool).
Actions: tap, long_press, swipe (x,y -> x2,y2, ms=duration; use for scrolling and dragging timeline handles),
type (text into the focused field; tap the field first), back, home, recents, open_app (text = app name),
wait (seconds), ask_user (text = your question), done (text = summary).
Rules:
- Read the screen carefully. Use the real buttons you see, not memory of how the app looked before.
- If the last action had no visible effect, try something different.
- Set needs_confirm=true for anything destructive or final: export, delete, overwrite, discard, exit without saving.
- Ignore the small dark floating panel (Roko / Haan / Nahi); it belongs to the agent.
- Never enter passwords or touch payments, chats or anything outside the task. If you are unsure, use ask_user.
- When the task is complete, return action done."""

    @Volatile var running = false
    @Volatile private var stop = false
    private val ui = Handler(Looper.getMainLooper())
    private val answer = LinkedBlockingQueue<Boolean>()
    private var panel: LinearLayout? = null
    private var status: TextView? = null
    private var confirmRow: LinearLayout? = null

    fun start(svc: AgentService, task: String, key: String) {
        if (running) return
        running = true
        stop = false
        ui.post { showPanel(svc) }
        Thread {
            try {
                loop(svc, task, key)
            } catch (e: Exception) {
                say("Dikkat: ${e.message}")
            } finally {
                running = false
                ui.postDelayed({ hidePanel(svc) }, 5000)
            }
        }.start()
    }

    private fun say(s: String) { ui.post { status?.text = s } }

    private fun showPanel(svc: AgentService) {
        hidePanel(svc)
        val ll = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD202020.toInt())
            setPadding(20, 10, 20, 10)
        }
        status = TextView(svc).apply { setTextColor(Color.WHITE); textSize = 12f; maxWidth = 520; text = "Shuru..." }
        val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
        row.addView(Button(svc).apply { text = "Haan"; setOnClickListener { answer.offer(true) } })
        row.addView(Button(svc).apply { text = "Nahi"; setOnClickListener { answer.offer(false) } })
        confirmRow = row
        val stopBtn = Button(svc).apply {
            text = "Roko"
            setOnClickListener { stop = true; answer.offer(false); say("Rok raha hoon...") }
        }
        ll.addView(status); ll.addView(row); ll.addView(stopBtn)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; y = 160 }
        (svc.getSystemService(AccessibilityService.WINDOW_SERVICE) as WindowManager).addView(ll, lp)
        panel = ll
    }

    private fun hidePanel(svc: AgentService) {
        panel?.let {
            try { (svc.getSystemService(AccessibilityService.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        panel = null
    }

    private fun confirm(a: JSONObject): Boolean {
        ui.post { status?.text = "Ye karne doon? " + a.optString("thought"); confirmRow?.visibility = View.VISIBLE }
        answer.clear()
        val r = answer.poll(60, TimeUnit.SECONDS) ?: false
        ui.post { confirmRow?.visibility = View.GONE }
        return r
    }

    private fun loop(svc: AgentService, task: String, key: String) {
        val hist = ArrayList<String>()
        for (step in 1..MAX_STEPS) {
            if (stop) { say("Roka gaya."); return }
            val img = svc.screenshotBase64() ?: run { say("Screenshot nahi mila (secure screen ho sakti hai)."); return }
            say("Step $step: soch raha hai...")
            val a = think(key, task, hist, img)
            if (stop) { say("Roka gaya."); return }
            val kind = a.optString("action")
            say("$step. $kind: ${a.optString("thought")}")
            if (kind == "done") { say("Ho gaya: " + a.optString("text")); return }
            if (kind == "ask_user") { say("Agent puchta hai: " + a.optString("text")); return }
            if (a.optBoolean("needs_confirm") && !confirm(a)) { say("Roka gaya."); return }
            act(svc, kind, a)
            hist.add("$step. $kind ${a.optInt("x")},${a.optInt("y")} ${a.optString("text")}")
            if (hist.size >= 3 && hist.takeLast(3).map { it.substringAfter(". ") }.toSet().size == 1) {
                say("Agent ek hi action dohra raha hai, ruk gaya."); return
            }
            Thread.sleep(1000)
        }
        say("Step limit pahunch gayi, ruk gaya.")
    }

    private fun act(svc: AgentService, kind: String, a: JSONObject) {
        val x = (a.optInt("x") / 1000f * svc.w).toInt()
        val y = (a.optInt("y") / 1000f * svc.h).toInt()
        val x2 = (a.optInt("x2") / 1000f * svc.w).toInt()
        val y2 = (a.optInt("y2") / 1000f * svc.h).toInt()
        when (kind) {
            "tap" -> svc.tap(x, y)
            "long_press" -> svc.longPress(x, y)
            "swipe" -> svc.swipe(x, y, x2, y2, a.optLong("ms", 400))
            "type" -> svc.typeText(a.optString("text"))
            "back" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "recents" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            "open_app" -> if (!svc.openApp(a.optString("text"))) say("App nahi mila: " + a.optString("text"))
            "wait" -> Thread.sleep((a.optDouble("seconds", 1.0) * 1000).toLong())
        }
    }

    private fun think(key: String, task: String, hist: List<String>, img: String): JSONObject {
        val prompt = "Task: $task\nSteps so far:\n" + hist.takeLast(8).joinToString("\n").ifEmpty { "(none)" }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray()
                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", img)))
                .put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.1))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.doOutput = true
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code !in 200..299) throw RuntimeException("API $code: " + txt.take(160))
        val t = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
        return if (t.startsWith("[")) JSONArray(t).getJSONObject(0) else JSONObject(t)
    }
}
